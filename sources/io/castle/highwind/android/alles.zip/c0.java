package io.castle.highwind.android;

import io.castle.highwind.android.e0;

/* loaded from: classes2.dex */
public abstract class c0 {

    /* renamed from: a, reason: collision with root package name */
    public final String f765a;
    public final String b;

    public c0() {
        e0.a aVar = e0.f770a;
        this.f765a = aVar.c();
        this.b = w.a(aVar.b() / 15) + w.a(aVar.a() / 15);
    }
}
