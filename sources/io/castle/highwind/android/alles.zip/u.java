package io.castle.highwind.android;

/* loaded from: classes2.dex */
public abstract class u {
}
