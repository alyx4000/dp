package io.castle.highwind.android;

/* loaded from: classes2.dex */
public abstract class l {
    public abstract String a(String str);
}
