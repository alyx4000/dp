package io.castle.highwind.android;

/* loaded from: classes2.dex */
public final class b extends l {
    @Override // io.castle.highwind.android.l
    public final String a(String str) {
        return k.f775a.a(str);
    }
}
