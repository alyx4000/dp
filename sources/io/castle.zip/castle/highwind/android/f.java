package io.castle.highwind.android;

import android.content.Context;

/* loaded from: classes2.dex */
public final class f extends z {
    public final Context b;
    public final d0 c;
    public final int d;
    public final e e;
    public final g f;

    public f(Context context, String str, d0 d0Var, int i) {
        super(str);
        this.b = context;
        this.c = d0Var;
        this.d = i;
        this.e = new e(context);
        this.f = new g(context);
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:41:0x027c A[LOOP:1: B:40:0x027a->B:41:0x027c, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:44:0x0283  */
    /* JADX WARN: Removed duplicated region for block: B:47:0x02ba  */
    /* JADX WARN: Removed duplicated region for block: B:50:0x02d7  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x02f4  */
    /* JADX WARN: Removed duplicated region for block: B:56:0x030f  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x039a  */
    /* JADX WARN: Removed duplicated region for block: B:79:0x043a  */
    /* JADX WARN: Removed duplicated region for block: B:82:0x0459 A[LOOP:2: B:81:0x0457->B:82:0x0459, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:85:0x043d  */
    /* JADX WARN: Removed duplicated region for block: B:86:0x03a9  */
    /* JADX WARN: Type inference failed for: r14v21, types: [java.util.LinkedHashMap, java.util.Map<java.lang.Integer, java.lang.Integer>] */
    @Override // io.castle.highwind.android.z
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct code enable 'Show inconsistent code' option in preferences
    */
    public final io.castle.highwind.android.y a() {
        /*
            Method dump skipped, instructions count: 1487
            To view this dump change 'Code comments level' option to 'DEBUG'
        */
        throw new UnsupportedOperationException("Method not decompiled: io.castle.highwind.android.f.a():io.castle.highwind.android.y");
    }
}
