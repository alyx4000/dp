package io.castle.highwind.android;

/* loaded from: classes2.dex */
public final class n {

    /* renamed from: a, reason: collision with root package name */
    public static final a f777a = new a();
    public static final Double[] b = {Double.valueOf(-180.0d), Double.valueOf(180.0d)};
    public static final Double[] c = {Double.valueOf(-90.0d), Double.valueOf(90.0d)};
    public static final t d = new t();

    public static final class a {
    }
}
