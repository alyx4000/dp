package io.castle.highwind.android;

import java.util.List;
import kotlin.collections.CollectionsKt;

/* loaded from: classes2.dex */
public final class a0 {

    /* renamed from: a, reason: collision with root package name */
    public static final a f762a = new a();

    public static final class a {
        /* JADX WARN: Multi-variable type inference failed */
        public static String a(String str, int i, String str2, List list, List list2, int i2) {
            a aVar = a0.f762a;
            if ((i2 & 16) != 0) {
                list2 = CollectionsKt.emptyList();
            }
            return aVar.a(i, str2, list, list2, false) + w.a(str.length(), 3) + w.a(str);
        }

        /* JADX WARN: Removed duplicated region for block: B:20:0x013c  */
        /* JADX WARN: Removed duplicated region for block: B:23:0x0157 A[SYNTHETIC] */
        /*
            Code decompiled incorrectly, please refer to instructions dump.
            To view partially-correct code enable 'Show inconsistent code' option in preferences
        */
        public final java.lang.String a(int r16, java.lang.String r17, java.util.List<java.lang.String> r18, java.util.List<java.lang.String> r19, boolean r20) {
            /*
                Method dump skipped, instructions count: 394
                To view this dump change 'Code comments level' option to 'DEBUG'
            */
            throw new UnsupportedOperationException("Method not decompiled: io.castle.highwind.android.a0.a.a(int, java.lang.String, java.util.List, java.util.List, boolean):java.lang.String");
        }
    }
}
