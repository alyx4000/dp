package io.castle.android;

/* loaded from: classes2.dex */
public final class BuildConfig {
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "io.castle.android";
    public static final int VERSION_CODE = 1;
    public static final String VERSION_NAME = "3.0.8";
}
