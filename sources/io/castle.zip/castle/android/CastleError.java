package io.castle.android;

/* loaded from: classes2.dex */
public class CastleError extends Error {
    public CastleError(String str) {
        super(str);
    }
}
