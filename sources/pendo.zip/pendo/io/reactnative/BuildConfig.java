package pendo.io.reactnative;

/* loaded from: classes6.dex */
public final class BuildConfig {
    public static final String BUILD_TYPE = "release";
    public static final boolean DEBUG = false;
    public static final String LIBRARY_PACKAGE_NAME = "pendo.io.reactnative";
}
