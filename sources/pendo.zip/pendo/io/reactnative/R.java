package pendo.io.reactnative;

/* loaded from: classes6.dex */
public final class R {
    private R() {
    }
}
